<?php

$conn= mysqli_connect('localhost','root','','assignment');  //localhost,username(root),pass,

//Write at least 2 functions for open and close connection to database.
?>